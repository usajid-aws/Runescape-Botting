package scripts;

import org.tribot.api.General;
import org.tribot.api.Timing;
import org.tribot.api.input.Mouse;
import org.tribot.api2007.ChooseOption;
import org.tribot.api2007.Game;
import org.tribot.api2007.Inventory;
import org.tribot.api2007.Objects;
import org.tribot.api2007.Player;
import org.tribot.api2007.types.RSGEOffer.TYPE;
import org.tribot.api2007.types.RSItem;
import org.tribot.api2007.types.RSObject;
import org.tribot.script.Script;
import org.tribot.script.ScriptManifest;
import org.tribot.api2007.Interfaces;


@ScriptManifest(authors = { "usama" }, category = "Smithing", name = "SmeltCannon")
public class SmeltCannon extends Script{
	
	Timer timer = new Timer(3000);
	private final int furnace = 24009; // furnace ID in Al-Kharid
	private final int steelBar = 2353;
	
	private boolean onStart()
	{
		System.out.println("Script has started");
		return true;
	}

	@Override
	public void run() 
	{
		if(onStart())
		{
			while(true)
			{
				sleep(work());
			}
		}
		
	}
	
	private int work()
	{
		RSItem[] bar = Inventory.find(steelBar);
		RSItem steel_Bar = bar[0];
		if(bar==null)
		{
			return 0; //placeholder will go to bank and exchange
		}
		else
		{
			
			if(Player.getRSPlayer().getAnimation() == -1)
			{
				while(bar.length>0)
				{
				RSObject[] furn = Objects.findNearest(10, furnace);
				RSObject burner = furn[0];
				steel_Bar.click("Use");
				String uptext = Game.getUptext();
				if (uptext != null && uptext.equalsIgnoreCase("Use Steel Bar ->"))
				{
					
					burner.click("Use Steel Bar -> Furnace");
					sleep(1000);
					Mouse.clickBox(220, 390, 270, 440, 3);
					sleep(1000);
					Timing.waitChooseOption("Make all", 6000);
					sleep(6500);
					if(bar.length==0) break;
					steel_Bar= bar[bar.length-1];
					while(Player.getRSPlayer().getAnimation()==-1 && timer.isRunning())
					{
						sleep(50);
					}					
								
				}
				
				
				}
				
				println("broke out");
							
			}
				
				
		}
		
		return 45;
		}

}

